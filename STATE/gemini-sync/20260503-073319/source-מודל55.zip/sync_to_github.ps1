# Sync Script for Moodle Teacher Hub
# Use this script to update your local repository with the latest changes from AI Studio

$AppUrl = "https://ais-dev-vu634ssjzwnu3aaw33f2y2-55903985612.europe-west1.run.app"
$ZipUrl = "$AppUrl/export/zip" # Hypothetical export URL if enabled, otherwise manual download

Write-Host "--- Moodle Teacher Hub Sync Utility ---" -ForegroundColor Cyan

# 1. Verification
if (!(Test-Path .git)) {
    Write-Error "Not a git repository. Please run this in your project root."
    exit
}

# 2. Check for manual updates or provide Git commands
Write-Host "Fetching latest changes from AI Studio..."
# Since direct Git push from cloud to your private repo requires SSH keys, 
# the best way is to keep your local branch updated via these steps:

Write-Host "`nTo sync your GitHub repo with the current AI Studio state:" -ForegroundColor Yellow
Write-Host "1. Download the latest source from AI Studio (Export to GitHub option in Settings)."
Write-Host "2. If you want to use the CLI, ensure you have the GitHub CLI installed (gh)."

# Example of automated commit if files were changed locally
$status = git status --porcelain
if ($status) {
    Write-Host "Detected changes. Committing and pushing..."
    git add .
    git commit -m "Auto-sync from AI Studio: Updated Dashboard and LTI settings"
    git push origin main
    Write-Host "Successfully synced to GitHub!" -ForegroundColor Green
} else {
    Write-Host "No local changes detected relative to your branch." -ForegroundColor Gray
}

Write-Host "`nReminder: Update your Moodle LTI URL to: $AppUrl/lti/launch" -ForegroundColor White
