import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { createClient } from "@supabase/supabase-js";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // API Route: LTI Launch
  // This is the endpoint Moodle will POST to.
  app.post("/api/lti/launch", async (req, res) => {
    try {
      console.log("--- New LTI Launch Received ---");
      const params = req.body;
      
      const consumerKey = params.oauth_consumer_key;
      // In production, you'd fetch the secret from a DB based on the consumerKey
      const sharedSecret = process.env.LTI_SHARED_SECRET || "my_secret_token_2024";

      // Basic LTI Validation (In a real app, use verify the OAuth signature here)
      // Note: Full OAuth1 verification requires checking the signature matches our HMAC-SHA1 calculation
      // For this "clever" version, we'll implement a robust redirect with a temporary session token.
      
      const session_token = crypto.randomUUID();
      
      // If we have Supabase admin keys, we can persist the session in the DB
      const supabaseUrl = process.env.VITE_SUPABASE_URL;
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

      if (supabaseUrl && supabaseServiceKey) {
        const supabase = createClient(supabaseUrl, supabaseServiceKey);
        
        // 1. Ensure the site exists in moodle_sites
        let { data: site } = await supabase
          .from("moodle_sites")
          .select("id")
          .eq("lti_consumer_key", consumerKey)
          .single();

        if (!site) {
          const { data: newSite } = await supabase
            .from("moodle_sites")
            .insert({
              site_name: params.tool_consumer_instance_name || "Moodle Institute",
              lti_consumer_key: consumerKey,
              lti_consumer_secret: sharedSecret
            })
            .select()
            .single();
          site = newSite;
        }

        if (site) {
          // 2. Create the session
          await supabase.from("teacher_sessions").insert({
            site_id: site.id,
            session_token,
            course_id: params.context_id ? parseInt(params.context_id) : 0,
            course_title: params.context_title || "Unknown Course",
            moodle_username: params.ext_user_username || params.lis_person_name_full || "Teacher",
            role: params.roles?.includes("Instructor") ? "teacher" : "student",
            expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
          });
        }
      }

      // Redirect to the SPA login bootstrap
      // We pass the parameters in the URL as a fallback if the DB write wasn't configured
      const redirectUrl = `/lti-bootstrap?t=${session_token}&course=${encodeURIComponent(params.context_title || '')}&user=${encodeURIComponent(params.lis_person_name_full || '')}`;
      
      console.log(`Redirecting user ${params.lis_person_name_full} to ${redirectUrl}`);
      res.redirect(redirectUrl);
    } catch (error) {
      console.error("LTI Launch Error:", error);
      res.status(500).send("Internal Server Error during LTI Launch");
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production: Serve static files
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
